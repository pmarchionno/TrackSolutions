package com.example.tracksolutions.ui.reportes

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ReportesScreen() {
    Text("Pantalla de Reportes")
}
