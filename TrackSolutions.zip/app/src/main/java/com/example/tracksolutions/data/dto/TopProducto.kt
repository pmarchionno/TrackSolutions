package com.example.tracksolutions.data.dto

data class TopProducto(
    val nombre: String,
    val unidades: Int
)