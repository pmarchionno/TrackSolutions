package com.example.tracksolutions.data.dto

data class TopCliente(
    val nombre: String,
    val total: Double
)
